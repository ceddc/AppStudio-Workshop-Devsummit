function getGeoRSSPoints(url) {

}
